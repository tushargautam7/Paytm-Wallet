//backend/config.js
module.exports = {
	JWT_SECRET: "your-jwt-secret"
}